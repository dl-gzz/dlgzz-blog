# 龙虾（OpenClaw）

使用：

`openclaw mcp add one-worker-os --url https://www.dlgzz.com/mcp --transport streamable-http --auth oauth`
`openclaw mcp login one-worker-os`

也可以在 Control UI 的 MCP 设置中导入 openclaw.json。
