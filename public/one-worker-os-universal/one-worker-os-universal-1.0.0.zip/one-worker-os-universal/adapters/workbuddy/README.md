# WorkBuddy

安装同目录的 one-worker-os-marketplace ZIP，然后在 WorkBuddy 插件市场安装并启用：

`one-worker-os@one-worker-os-marketplace`

安装后从“连接器 → 自定义连接器 → 我的 MCP → one-worker-os → 连接”发起 OAuth。
