# one-worker-os 通用安装包

这是 OneWorkerOS 的通用客户端安装包。请把整个 ZIP 交给当前 AI 客户端读取；它会根据当前宿主选择 WorkBuddy、豆包或龙虾（OpenClaw）入口。

核心服务只有一个：

- MCP：https://www.dlgzz.com/mcp
- 授权：由客户端发起 OAuth，用户在浏览器中点击允许
- 会员和知识库：由 OneWorkerOS 云端统一管理

详细步骤见 INSTALL.md。
